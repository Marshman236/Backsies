There are missing files because I deleted files I do not currently have. These are all of the ones I currently do have. New card files are planned to fix this.

Sorry for the inconvenience!